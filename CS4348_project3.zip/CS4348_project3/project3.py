#!/usr/bin/env python3
"""CS 4348 Project‑3 – 512‑B B‑Tree index manager"""

import argparse, csv, pathlib, sys

# ── spec constants
BLOCK, MAGIC, T = 512, b"4348PRJ3", 10
MAX_KV, MAX_CH  = 2*T - 1, 2*T          # 19 keys, 20 kids

be   = lambda n: n.to_bytes(8,"big")
u64  = lambda b: int.from_bytes(b,"big")

# ── raw I/O helpers
def rblk(fp,b): fp.seek(b*BLOCK); return fp.read(BLOCK)
def wblk(fp,b,buf): fp.seek(b*BLOCK); fp.write(buf if len(buf)==BLOCK else buf.ljust(BLOCK,b"\0"))

# ── header helpers
def hdr_new():  return MAGIC + be(0)+be(1) + b"\0"*(BLOCK-24)
def hdr_load(buf): return {"root":u64(buf[8:16]), "next":u64(buf[16:24])}
def hdr_save(fp,h): wblk(fp,0, MAGIC+be(h["root"])+be(h["next"]))

# ── Node (fits one 512‑B block)
class Node:
    def __init__(s,bid,par=0,n=0,keys=None,vals=None,kids=None):
        s.bid,s.par,s.n = bid,par,n
        s.k = keys or [0]*MAX_KV
        s.v = vals or [0]*MAX_KV
        s.c = kids or [0]*MAX_CH
    def leaf(s): return s.c[0]==0
    def slot(s,key):
        i=0
        while i<s.n and key>s.k[i]: i+=1
        return i
    # serialise
    def pack(s):
        out = be(s.par)+be(s.n)
        for arr,cap in ((s.k,MAX_KV),(s.v,MAX_KV),(s.c,MAX_CH)):
            for i in range(cap): out += be(arr[i])
        return out.ljust(BLOCK,b"\0")
    @classmethod
    def unpack(cls,bid,buf):
        par,n = u64(buf[:8]), u64(buf[8:16])
        off=16
        k=[u64(buf[i:i+8]) for i in range(off,off+8*MAX_KV,8)]
        off+=8*MAX_KV
        v=[u64(buf[i:i+8]) for i in range(off,off+8*MAX_KV,8)]
        off+=8*MAX_KV
        c=[u64(buf[i:i+8]) for i in range(off,off+8*MAX_CH,8)]
        return cls(bid,par,n,k,v,c)

def rd(fp,bid): return Node.unpack(bid,rblk(fp,bid))
def wr(fp,node): wblk(fp,node.bid,node.pack())

# ── utilities
def alloc(fp,h,parent):
    bid=h["next"]; h["next"]+=1
    n=Node(bid,parent)
    wr(fp,n); return n

def split(fp,h,parent,i):
    full=rd(fp,parent.c[i]); mid=T-1
    right=alloc(fp,h,parent.bid)
    right.n = full.n-mid-1
    right.k[:right.n] = full.k[mid+1:full.n]
    right.v[:right.n] = full.v[mid+1:full.n]
    right.c[:right.n+1] = full.c[mid+1:full.n+1]
    full.n = mid
    parent.k[i+1:parent.n+1] = parent.k[i:parent.n]
    parent.v[i+1:parent.n+1] = parent.v[i:parent.n]
    parent.c[i+2:parent.n+2] = parent.c[i+1:parent.n+1]
    parent.k[i],parent.v[i] = full.k[mid],full.v[mid]
    parent.c[i+1] = right.bid
    parent.n += 1
    wr(fp,full); wr(fp,right); wr(fp,parent)

def insert_nonfull(fp,h,node,key,val):
    i=node.slot(key)
    if node.leaf():
        if i<node.n and key==node.k[i]: node.v[i]=val; wr(fp,node); return
        node.k[i+1:node.n+1] = node.k[i:node.n]
        node.v[i+1:node.n+1] = node.v[i:node.n]
        node.k[i],node.v[i],node.n = key,val,node.n+1
        wr(fp,node); return
    child=rd(fp,node.c[i])
    if child.n==MAX_KV:
        split(fp,h,node,i)
        if key>node.k[i]: i+=1
        child=rd(fp,node.c[i])
    insert_nonfull(fp,h,child,key,val)

def bt_insert(fp,h,key,val):
    if h["root"]==0:
        r=alloc(fp,h,0); r.n=1; r.k[0],r.v[0]=key,val; wr(fp,r); h["root"]=r.bid; return
    root=rd(fp,h["root"])
    if root.n==MAX_KV:
        new=alloc(fp,h,0); new.c[0]=root.bid; wr(fp,root); split(fp,h,new,0); h["root"]=new.bid
        insert_nonfull(fp,h,new,key,val)
    else:
        insert_nonfull(fp,h,root,key,val)

def bt_search(fp,bid,key):
    while bid:
        n=rd(fp,bid); i=n.slot(key)
        if i<n.n and key==n.k[i]: return n.v[i]
        bid=n.c[i]
    return None

def inorder(fp,bid):
    if bid==0: return
    n=rd(fp,bid)
    for i in range(n.n):
        yield from inorder(fp,n.c[i])
        yield n.k[i],n.v[i]
    yield from inorder(fp,n.c[n.n])

def load_csv(fp,h,csvfile):
    with open(csvfile) as f:
        for k,v in csv.reader(f):
            bt_insert(fp,h,int(k),int(v))

# ── CLI --------------------------------------------------------------
def need(rest, n, usage):
    if len(rest)!=n:
        sys.exit(f"usage: {usage}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("cmd",choices=["create","insert","search","load","print","extract"])
    ap.add_argument("rest",nargs="*")
    a=ap.parse_args()

    if a.cmd=="create":
        need(a.rest,1,"create <idxfile>")
        idx=pathlib.Path(a.rest[0]); idx.exists() and sys.exit("file exists")
        with open(idx,"wb")as fp: wblk(fp,0,hdr_new())
        print("created",idx)

    elif a.cmd=="insert":
        need(a.rest,3,"insert <idxfile> key val")
        idx,k,v=a.rest; k,v=int(k),int(v)
        with open(idx,"r+b")as fp:
            h=hdr_load(rblk(fp,0)); bt_insert(fp,h,k,v); hdr_save(fp,h)

    elif a.cmd=="search":
        need(a.rest,2,"search <idxfile> key")
        idx,k=a.rest; k=int(k)
        with open(idx,"rb")as fp:
            h=hdr_load(rblk(fp,0)); print(bt_search(fp,h["root"],k) or "NOT‑FOUND")

    elif a.cmd=="load":
        need(a.rest,2,"load <idxfile> csvfile")
        idx,csvf=a.rest
        with open(idx,"r+b")as fp:
            h=hdr_load(rblk(fp,0)); load_csv(fp,h,csvf); hdr_save(fp,h)

    elif a.cmd=="print":
        need(a.rest,1,"print <idxfile>")
        idx=a.rest[0]
        with open(idx,"rb")as fp:
            h=hdr_load(rblk(fp,0))
            for k,v in inorder(fp,h["root"]): print(k,v)

    elif a.cmd=="extract":
        need(a.rest,2,"extract <idxfile> out.csv")
        idx,out=a.rest
        with open(idx,"rb")as fp, open(out,"w",newline="") as f:
            h=hdr_load(rblk(fp,0)); csv.writer(f).writerows(inorder(fp,h["root"]))

if __name__=="__main__":
    main()

