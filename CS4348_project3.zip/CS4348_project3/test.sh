#!/usr/bin/env bash
set -euo pipefail
rm -f try.idx
python3 project3.py create try.idx
for k in {1..50}; do
  python3 project3.py insert try.idx $k $((k*5))
done
cnt=$(python3 project3.py print try.idx | wc -l)
[[ "$cnt" -eq 50 ]] && echo "✓ 50 keys OK"
