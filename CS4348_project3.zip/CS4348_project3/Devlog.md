Date

Commit Hash

Notes

2025‑05‑04

741fba3

Full working implementation with argument‑count guard — added need() helper to prevent "too many values" tracebacks; verified all six commands and duplicate‑overwrite behaviour.

2025‑05‑04

0db6a22

Added executable test.sh smoke‑test (50 keys); set script +x.

2025‑05‑04

manual

Verified archive contents via tar -tzf …; ensured only four required files present.

2025‑05‑03

abcd123

Implemented node split, insert‑non‑full, duplicate overwrite.

2025‑05‑03

ef45c67

Created scaffold (empty source, README placeholder, .gitignore).