This project implements a minimal‑degree‑10 B‑Tree stored on disk in fixed 512‑byte blocks.  It supports six CLI commands (create, insert, search, load, print, extract) and guarantees that no more than three B‑Tree nodes are resident in memory at any time.  The code is 100 % POSIX‑compliant Python 3 and runs unchanged on Intel or Apple‑silicon macOS.

Folder layout

File

Purpose

project3.py

Main driver & B‑Tree implementation (single file)

test.sh

50‑key smoke‑test script (bash)

.gitignore

Ignore cache/virtual‑env/artefacts

README.md (this section)

How to build, run, test, package

DEVLOG.md

Day‑by‑day development notes

Requirements

Python ≥ 3.10

(Optional) Homebrew for easy Python installation on macOS

Quick‑start (Terminal)

# 1  create an empty index
python3 project3.py create demo.idx

# 2  insert / search single key
python3 project3.py insert demo.idx 42 420
python3 project3.py search demo.idx 42   # prints 420

# 3  bulk‑load from CSV (duplicates overwrite)
echo -e "1,10\n20,200\n42,999" > tiny.csv
python3 project3.py load demo.idx tiny.csv

# 4  dump sorted key/value pairs
python3 project3.py print demo.idx

Command reference

Command

Syntax

Effect

create

create <idxfile>

Initialise new index; refuses if file exists

insert

insert <idxfile> key val

Insert or overwrite (key,val)

search

search <idxfile> key

Print value or NOT‑FOUND

load

load <idxfile> csvfile

Stream‑insert rows from CSV

print

print <idxfile>

In‑order traversal to stdout

extract

extract <idxfile> out.csv

Dump all pairs to CSV

Running the smoke‑test

./test.sh    # prints "✓ 50 keys OK" on success

The script creates a temporary try.idx, inserts 50 unique keys, and asserts that exactly 50 lines are printed.

Packaging for submission

git tag v1.0-submission
git archive --format=tar --prefix=CS4348_project3/ v1.0-submission \
        | gzip > AbdulAzeem_Project3.tgz

Verify:

tar -tzf AbdulAzeem_Project3.tgz | head

